# armada

![Version: 0.0.0-latest](https://img.shields.io/badge/Version-0.0.0--latest-informational?style=flat-square)

Armada Server is the centralized Control Plane for Armada, the multi-cluster batch scheduler.

## Prerequisites

Armada Server requires the following components to be accessible and configured:
* [Pulsar](https://pulsar.apache.org/) - open-source, distributed messaging and streaming platform built for the cloud.
* [Redis](https://redis.io/) - open source, in-memory data store
* [Postgres](https://www.postgresql.org/) - powerful, open source object-relational database
* [cert-manager](https://cert-manager.io/) - Kubernetes certificate management controller

## Install

Add `gresearch` Helm repository and fetch latest charts info:

```sh
helm repo add gresearch https://g-research.github.io/charts
helm repo update
```

Install `armada-server` using Helm:

```sh
helm install armada-server gresearch/armada \
    --set ingress.enabled=false
```

## Uninstall

Uninstall armada-server using Helm:

```sh
helm uninstall armada-server
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalLabels | object | `{}` | Additional labels for all Armada Server K8s resources |
| additionalVolumeMounts | list | `[]` | Additional volume mounts for Armada Server Deployment resource |
| additionalVolumes | list | `[]` | Additional volumes for Armada Server Deployment resource |
| applicationConfig.grpc.tls.certPath | string | `"/certs/tls.crt"` |  |
| applicationConfig.grpc.tls.enabled | bool | `false` |  |
| applicationConfig.grpc.tls.keyPath | string | `"/certs/tls.key"` |  |
| applicationConfig.grpcPort | int | `50051` | Armada Server gRPC port |
| applicationConfig.httpPort | int | `8080` | Armada Server REST port |
| applicationConfig.pulsar.authenticationEnabled | bool | `false` | Toggle whether to mount Pulsar Token secret |
| applicationConfig.pulsar.authenticationSecret | string | `"armada-pulsar-token-armada-admin"` | Name of the secret which contains the Pulsar Token |
| applicationConfig.pulsar.cacert | string | `"armada-pulsar-ca-tls"` | Name of the secret which contains the Pulsar CA certificate |
| applicationConfig.pulsar.tlsEnabled | bool | `false` | Toggle whether to mount Pulsar CA certificate secret |
| clusterIssuer | string | `""` | cert-manager's ClusterIssuer from which to request TLS certificate for the Ingres resources |
| containerSecurityContext | object | `{"allowPrivilegeEscalation":false}` | Security Context for armada Container |
| customServiceAccount | string | `""` | If specified, custom ServiceAccount name will be attached to Armada Server Deployment resource and the default ServiceAccount will not be created |
| env | object | `{}` | Additional environment variables for Armada Server Deployment resource |
| fullnameOverride | string | `""` |  |
| grpcHostnames | list | `[]` | Hostnames for which to create gRPC Ingress rules, overriding `hostnames` if set |
| hostnames | list | `[]` | Hostnames for which to create gRPC and REST Ingress rules |
| image.repository | string | `"gresearch/armada-server"` |  |
| image.tag | string | `"0.0.0-latest"` |  |
| ingress.annotations | object | `{}` | Additional annotations for Ingress resource |
| ingress.enabled | bool | `true` | Toggle whether to create gRPC and HTTP Ingress for Armada Server |
| ingress.labels | object | `{}` | Additional labels for Ingress resource |
| ingress.nameOverride | string | `""` | Ingress resource name override |
| ingressClass | string | `"nginx"` |  |
| nameOverride | string | `""` |  |
| podDisruptionBudget | object | `{}` |  |
| podSecurityContext | object | `{}` | Pod Security Context |
| prometheus.enabled | bool | `false` | Toggle whether to install ServiceMonitor and PrometheusRule for Armada Server monitoring |
| prometheus.labels | object | `{}` | Additional labels for ServiceMonitor and PrometheusRule |
| prometheus.scrapeInterval | string | `"15s"` | Prometheus scrape interval |
| prometheus.scrapeTimeout | string | `"10s"` | Prometheus scrape timeout |
| replicas | int | `1` | Armada Server replica count |
| resources.limits.cpu | string | `"300m"` |  |
| resources.limits.memory | string | `"1Gi"` |  |
| resources.requests.cpu | string | `"200m"` |  |
| resources.requests.memory | string | `"512Mi"` |  |
| restHostnames | list | `[]` | Hostnames for which to create REST Ingress rules, overriding `hostnames` if set |
| routableService.enabled | bool | `false` |  |
| serviceAccount | object | `{}` | Additional ServiceAccount properties (e.g. automountServiceAccountToken, imagePullSecrets, etc.) |
| serviceType | string | `"ClusterIP"` |  |
| strategy.rollingUpdate.maxUnavailable | int | `1` |  |
| strategy.type | string | `"RollingUpdate"` |  |
| terminationGracePeriodSeconds | int | `30` | Number of seconds to wait for Armada Server to gracefully shutdown |
| tolerations | list | `[]` | Tolerations |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
